---
name: Kinetic Minimal
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#58605c'
  on-secondary: '#ffffff'
  secondary-container: '#dce5df'
  on-secondary-container: '#5e6662'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00210c'
  on-tertiary-container: '#00984f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#dce5df'
  secondary-fixed-dim: '#c0c9c3'
  on-secondary-fixed: '#151d1a'
  on-secondary-fixed-variant: '#404945'
  tertiary-fixed: '#7efba4'
  tertiary-fixed-dim: '#61de8a'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005228'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin: 24px
---

## Brand & Style
The brand personality of this design system is built on the pillars of reliability, efficiency, and modern sophistication. It targets urban commuters and professional travelers who value a seamless, friction-free experience. The UI evokes a sense of calm authority through a "Corporate Modern" aesthetic—balancing high-contrast primary elements with soft, organic backgrounds. 

The style utilizes a "Neo-Corporate" approach: a synthesis of minimalist layouts and tactile, rounded components. It avoids visual clutter, favoring purposeful whitespace and a high-clarity information hierarchy to ensure users can make quick decisions while on the move.

## Colors
The color palette is anchored by a high-contrast Black primary, used for core interactions and navigation to instill a sense of premium reliability. This is softened by a Secondary palette of "Muted Sage" and "Soft Mint" greens, specifically designed for large surface areas like map panels and container backgrounds to reduce eye strain. 

Tertiary greens are reserved for success states, active ride indicators, and price confirmations. The neutral scale favors cool grays to maintain a clean, clinical feel that ensures the primary brand black remains the focal point of the user journey.

## Typography
This design system employs **Manrope** as the sole typeface to maintain a modern, geometric, yet highly readable appearance. Manrope’s balanced proportions make it ideal for both large-scale headlines and dense data, such as ETA digits and pricing.

Headlines use a tighter letter-spacing and heavier weights to project confidence. Body text is optimized for legibility with generous line heights, while labels use medium to semi-bold weights to ensure functional clarity in high-utility areas like buttons and input fields.

## Layout & Spacing
The layout follows a fluid 12-column grid for desktop environments and a 4-column fluid grid for mobile devices. It utilizes an 8px base unit to drive a consistent rhythmic spacing model. 

Vertical spacing is generous to emphasize the minimalist aesthetic, while horizontal margins are kept at a comfortable 24px on mobile to ensure touch-targets remain accessible. Map-heavy views should treat the map as the bottom-most layer, with UI panels appearing as floating, stacked containers with consistent internal padding of 24px (md).

## Elevation & Depth
Depth is communicated through ambient shadows and tonal layering. Rather than harsh borders, the system uses extra-diffused, low-opacity shadows (Blur: 20px-40px, Opacity: 4-8%) to lift floating panels above the map.

Surface tiers are defined as:
1.  **Floor:** The Map or main background.
2.  **Raised:** Floating action buttons and ride-selection panels (Soft shadow).
3.  **Overlay:** Modals and bottom sheets (Deep, diffused shadow).
A subtle 1px inner stroke in a slightly darker green tint may be used on panels to provide definition against the soft green background without increasing visual weight.

## Shapes
The shape language is defined by extreme roundedness to promote a friendly and approachable user experience. A pill-shaped (fully rounded) approach is the standard for all interactive elements, including buttons, input fields, and search bars. 

Larger containers, such as ride-info cards and map panels, use a `rounded-xl` (3rem) radius to echo this pill-shaped theme while maintaining structural integrity. This lack of sharp corners reinforces the "flow" aspect of the brand, suggesting a smooth and safe journey.

## Components
-   **Buttons:** All buttons must be pill-shaped. Primary buttons use a solid black background with white typography. Secondary buttons use the soft green background with black typography.
-   **Input Fields:** Search and destination inputs are pill-shaped with a subtle gray border or a light green background. Focus states should transition the border to black.
-   **Cards:** Ride-option cards (e.g., Economy, XL, Luxury) utilize the `rounded-xl` corner radius. Selection is indicated by a thick black border or a change in background saturation.
-   **Chips:** Used for quick filters (e.g., "Recent", "Work", "Home"), these are small pill-shaped elements with a light green fill.
-   **Bottom Sheets:** These containers house the majority of the ride-hailing logic. They feature heavily rounded top corners (3rem) and a centered "drag handle" to indicate vertical interactivity.
-   **Vehicle Icons:** Should be simplified, minimalist silhouettes that align with the geometric nature of the typography.